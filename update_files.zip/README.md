# TravelEscape Telegram Bot

Telegram бот для турагентства "TravelEscape" - автоматизированная система подбора туров и управления контактами.

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Telegram](https://img.shields.io/badge/Telegram-Bot-blue.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

## ✨ Возможности

- 🎯 **Форма подбора тура** - 8-шаговый процесс оформления заявки
- 📞 **Контактная информация** - Адрес, телефон, email с режимом работы
- 🔙 **Умная навигация** - Кнопки "Назад" и "В начало" на любом этапе
- 💾 **База данных SQLite** - Хранение всех заявок
- 📨 **Уведомления менеджеру** - Мгновенные оповещения в Telegram
- 🐍 **Python** - Создан на библиотеке python-telegram-bot

## 🚀 Быстрый старт

1. **Клонируйте репозиторий**
```bash
git clone https://github.com/abkbggjdfybyf-dotcom/travelescape-telegram-bot.git
cd travelescape-telegram-bot
